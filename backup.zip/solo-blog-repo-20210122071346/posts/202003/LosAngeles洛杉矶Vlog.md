title: Los Angeles（洛杉矶）Vlog
date: '2020-03-01 06:56:13'
updated: '2020-07-22 16:46:22'
tags: [休假旅行游记, 心情随笔, 洛杉矶]
permalink: /articles/2020/03/01/1583042173751.html
---
![](https://img.hacpai.com/bing/20180109.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

从 2016 年开始，每年的春节都会去美国休息。以前都是一个人，但今年很特殊，多了一个人。于是我也尝试着从今年开始录制 Vlog 来保留这美好的时光，更希望以后的日子里我们都能互相陪伴，互相照顾。一同感受这世间的美好。

PS:第一次学习用 PR 剪视频，效果实在不咋地。😄 😄

https://disk.frank2019.me/index.php?user/publicLink&fid=a0ed5lcs27xeIF96i9Lg62Go3_yl9diMp17Ybh3C75LP9g6SnwfSpMm0wlaCsefZFmyaVqiPiripY5xToaUtl0XbvEc7x3tvVz3Xw5teRW_U6mfDQhU73EcIANsWbYIOK2eQzfEBO4Z5WIz9z3J7rg&file_name=/Los+Angeles+.mp4
