title: 在Ubuntu中禁用IPV6协议
date: '2020-11-30 04:35:47'
updated: '2020-11-30 04:48:44'
tags: [Ubuntu]
permalink: /articles/2020/11/30/1606707346964.html
---
![](https://b3logfile.com/bing/20180328.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近再搭建VPS的时候发现IPV6与IPV4再实际运用中，仍然会发生冲突，比如探针PING值会不准，加速连接容易超时等问题，所以再网上找到了关闭方法搬运到Blog，以备不时之需。

原文地址：https://www.sysgeek.cn/ubuntu-disable-ipv6/

#### 方法1：在Ubuntu中使用Sysctl禁用IPv6协议

在「终端」中执行以下命令——查看 IPv6 是否已经启用：

```
ip a
```

1.如果启用了 IPv6 协议（您的网卡名称可能不同），应该可以看到它：

![ip a](https://img.sysgeek.cn/img/2019/05/ubuntu-disable-ipv6-2.jpg)

2.要临时禁用 IPv6，您只需在「终端」中执行以下 3 条命令：

```
sudo sysctl -w net.ipv6.conf.all.disable_ipv6=1
sudo sysctl -w net.ipv6.conf.default.disable_ipv6=1
sudo sysctl -w net.ipv6.conf.lo.disable_ipv6=1
```



上述命令执行完成后，再用 ip a 查看 IPv6 是否禁用成功：

![sysctl](https://img.sysgeek.cn/img/2019/05/ubuntu-disable-ipv6-3.jpg)

> 注意：上述方法只是在 Ubuntu 系统中**临时禁用**了 IPv6 协议，重启后系统会自动再次启用 IPv6。

如果要在 Ubuntu 系统中永久禁用 IPv6，我们可以通过本文编辑器来修改 /etc/sysctl.conf 文件：

1.使用 VIM 或 Nano 等文件编辑器打开 /etc/sysctl.conf 配置文件

2.将以下 3 行内容添加到 /etc/sysctl.conf 配置文件当中:

```
net.ipv6.conf.all.disable_ipv6=1
net.ipv6.conf.default.disable_ipv6=1
net.ipv6.conf.lo.disable_ipv6=1
```

![sysctl.conf](https://img.sysgeek.cn/img/2019/05/ubuntu-disable-ipv6-4.jpg)

3.配置文件修改完成后，要使设置生效，还需要在「终端」中执行以下命令：

```
sudo sysctl -p
```

#### 方法2：在Ubuntu中通过GRUB禁用IPv6协议

在 Ubuntu 中禁用 IPv6 协议的另一种方法就是，将 GRUB 配置为在引导时传递内核参数：

1.使用 VIM 或 Nano 等文件编辑器编辑 /etc/default/grub 配置文件

![/etc/default/grub](https://img.sysgeek.cn/img/2019/05/ubuntu-disable-ipv6-5.jpg)

2.修改 GRUB_CMDLINE_LINUX_DEFAULT 和 GRUB_CMDLINE_LINUX 以在启动时禁用 IPv6：

```
GRUB_CMDLINE_LINUX_DEFAULT="quiet splash ipv6.disable=1"
GRUB_CMDLINE_LINUX="ipv6.disable=1"
```

![/etc/default/grub](https://img.sysgeek.cn/img/2019/05/ubuntu-disable-ipv6-6.jpg)

3配置文件修改完成后，要使设置生效，还需要在「终端」中执行以下命令：

```
sudo update-grub
```

GRUB 配置修改完成后，即便重启系统时配置也会保留。

