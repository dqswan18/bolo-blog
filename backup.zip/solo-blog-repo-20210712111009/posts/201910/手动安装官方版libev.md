title: 手动安装官方版libev
date: '2019-10-18 15:55:24'
updated: '2020-07-22 22:54:20'
tags: [技术分享, SS]
permalink: /articles/2019/10/18/1571385324555.html
---
一，你需要有Ubuntu 16.10 及以上 或 Debian 8 及以上  的系统  
二，执行以下代码：  

1. sudo apt update  
    
2. sudo apt install shadowsocks-libev
 
三，编写config.json文件，内容如下（按需求自行修改）：  

1. {  
    
2.     "server":"127.0.0.1",  
    
3.     "server_port":8389,  
    
4.     "local_port":1081,  
    
5.     "password":"salsa20_password",  
    
6.     "timeout":60,  
    
7.     "method":"chacha20-ietf-poly1305",  
    
8.     "local":"127.0.0.1",  
    
9.     "fast_open":false  
    
10. }


四，启动ss-server，代码如下：  

1. ss-server -c config.json

五，后台自动运行

1. nohup ss-server -c config.json &


