title: 宝塔Linux nginx http强制跳转https设置方法
date: '2019-09-06 04:14:35'
updated: '2020-07-22 16:50:42'
tags: [技术分享, https跳转]
permalink: /articles/2019/09/06/1567736075817.html
---
![](https://img.hacpai.com/bing/20180908.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

重新搬家香港服务器后放弃了cloudflare的免费DNS加速，实在是负加速。国内访问差不多都在180ms左右，而且巨卡无比。现在国内访问PING值也就是不到20ms，从美国洛杉矶机房访问也就是160ms，可以说如果我大部分时间在国内的话，完全不需要加速器了。在搭建的过程中出现了一个问题，虽然开启了宝塔的强制HTTPS访问，但是在不输入HTTPS直接访问网址的时候，会跳转到http，无法正常访问。其实只需要在nginx加入一段简单代码就可以解决这个问题了。
我们先找到-----域名.conf文件
宝塔Linux面板：/www/server/nginx/conf/vhost/目录下
下面代码照搬过去就行。无需做任何修改。春哥技术博客推荐此种方法，非常简单，改完以后实时生效，不用重启服务器。

```
`if ($scheme = http ) {return 301 [https://$host$request_uri](https://%24host%24request_uri/);}`
```
加在文件底部即可。
