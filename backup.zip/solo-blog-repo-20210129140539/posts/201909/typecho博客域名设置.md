title: typecho博客域名设置
date: '2019-09-22 19:01:29'
updated: '2020-07-22 22:55:37'
tags: [tyecho, 技术分享, 宝塔]
permalink: /articles/2019/09/22/1569150089146.html
---
![](https://img.hacpai.com/bing/20181129.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

  这两天弄了一个tyecho博客，在配置的过程中发现用WWW访问的时候首页有许多图标没有显示，于是看过主题代码发现原来是网站的图标调用的是绑定域名的绝对路径，所以导致用其他域名或显示不正常。

  没办法，只能采用301跳转了。可以直接在宝塔的重定向设置
![GXIHF9HBJLRUU.png](https://img.hacpai.com/file/2019/09/GXIHF9HBJLRUU-4740564d.png)

或是更改Nginx配置：
```
1. if  ($host ~  '^www.tian0616.com')
2. {return  301 https://tian0616.com$uri;}
```
最后更改下域名解析A记录到指定IP,这样所有域名就全部会跳转到指定的二级域名了。
感慨这些方面SOLO做的真的比其他的博客要好。

