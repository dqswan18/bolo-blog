title: 宝塔面板 – Java 项目管理器安装Solo博客教程
date: '2019-09-10 10:53:10'
updated: '2020-07-22 22:51:22'
tags: [技术分享, SOLO相关]
permalink: /articles/2019/09/10/1568083990075.html
---
![](https://img.hacpai.com/bing/20190223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最新通过宝塔部署了SOLO，在实际体验过程中发现该BLOG还是很好用的，除了必须绑定GITHUB这点上比较反人类（也可能是开发者的大构思，只是我们没有深刻去理解）其他方面都是很好的，重点是用不断更。所以现在使用起来也是非常不错的，在这里记录下自己的搭建过程和修改内容。并提出更新疑问。

#### 1.安装宝塔里面的JAVA管理器,然后选择安装Tomcat9

#### 2.找到tomcat的webapps的位置，直接下载进去，会自动给我们解压的
```
下载地址：https://github.com/b3log/solo/releases/
```
 #### 3.添加项目，域名提前解析好即可。
![image.png](https://img.hacpai.com/file/2019/09/image-0b1a2a9f.png)

#### 4.添加数据库

用户名Solo，格式utf8m64

![image.png](https://img.hacpai.com/file/2019/09/image-10db24af.png)

#### 5.配置local.properties
```
路径 /www/server/tomcat9/webapps/solo-v3.6.4/WEB-INF/classes
```
改成创建的数据库名称，和数据库密码。

#### 6.在JAVA管理器中映射该项目

#### 7.修改latke.properties
```
路径 /www/server/tomcat9/webapps/solo-v3.6.4/WEB-INF/classes
```
![image.png](https://img.hacpai.com/file/2019/09/image-a9df1ec6.png)

#### 8.宝塔设置反向代理，添加SSL证书。
![image.png](https://img.hacpai.com/file/2019/09/image-77626094.png)

大概流程就是这些。我这里还额外修改了几个文件。
```
页脚版权 /www/server/tomcat9/webapps/solo-v3.6.4/Skins/Casper/footer.ftl
```
```
客户端信息 /www/server/tomcat9/webapps/solo-v3.6.4/manifest.json
```

现在有个疑问，因为我没用Docker配置，那么以后升级应该怎么操作呢？会不会因为覆盖出错而导致灾难性的后果呢，这里还需要继续研究。
