title: Youtube 详细统计信息 详解
date: '2019-09-05 00:09:50'
updated: '2020-07-22 22:49:57'
tags: [技术分享]
permalink: /articles/2019/09/05/1567613389949.html
---
![](https://img.hacpai.com/bing/20180826.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

Video ID/ sCPN : 每个视频独特的独有的ID/用于识别问题的字符串（开发人员适用）

Viewport : 当前播放窗口的分辨率

Current / Optimal Res : 视频解析度/最佳解析度

Volume / Normalized : 当前音量百分百/实际输出音量百分百（与Youtube标准音量的响度差距）

Codecs : 媒体类型/格式

Color : 视频色域

Host : 为你推播流媒体的Youtube服务器主机名

Connection Speed : 链接速率，也是大家最常参考的数字，这个数字并不准确，由于youtube使用的是少量数据包，高频发送次数的调度方案，所以在低延迟服务器上这个数值会很大，而高延迟服务器的链接速率会明显偏小，请以本地实际实时速率为准

Network Activity : 网络活动

Buffer Health : 已缓存的视频时间

Dropped Frames ：由于网络或本地主机性能原因导致的丢帧数
