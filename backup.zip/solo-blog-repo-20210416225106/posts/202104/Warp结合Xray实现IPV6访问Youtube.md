title: Warp结合Xray实现IPV6访问Youtube
date: '2021-04-05 22:06:13'
updated: '2021-04-05 22:12:49'
tags: [技术分享, Xray, warp]
permalink: /articles/2021/04/05/1617631573424.html
---
![](https://b3logfile.com/bing/20210305.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近使用的VPS服务器遇到了一个问题，那就是我VPS服务器被标记成了中国IP，所以youtube会员、后台播放等功能都无法使用。
于是通过技术交流，发现可以套上Swarp来解决这个问题，通过两天不断的研究，终于解决了这个问题，做个流程，方便自己下次配置。

首先，安装Warp

> 参考文档
> 
> https://ybfl.xyz/111.html   #使用 Cloudflare WARP 给 VPS 服务器免费添加IPv6 网络
> https://www.imcxx.com/archives/80/   #使用CF WARP添加替换IPv4/IPv6
> https://p3terx.com/archives/use-cloudflare-warp-to-add-extra-ipv4-or-ipv6-network-support-to-vps-servers-for-free.html  #用 Cloudflare WARP 给 VPS 服务器免费添加 IPv4 或 IPv6 网络支
> https://www.v2fly.org/config/routing.html#ruleobject #routing修改

**安装步骤**

1.首先安装一些必要的工具，防止接下来的操作出问题。

```
apt update
apt install curl sudo lsb-release -y
```

---

2.安装网络工具包

```
sudo apt install net-tools iproute2 openresolv dnsutils -y
```

---

3.安装 wireguard-tools

```
sudo apt install wireguard-tools --no-install-recommends
```

---

4.安装 WireGuard

先执行命令查看内核版本。如果是 5.6 以上内核则已经集成了 Wire­Guard ，就不需要安装了。

```
unname -r
```

如果内核5.6以下，推荐全新内核安装

```
sudo apt -t $(lsb_release -sc)-backports install linux-image-$(dpkg --print-architecture) linux-headers-$(dpkg --print-architecture) --install-recommends -y
```

---

5.使用 wgcf 生成 WireGuard 配置文件

* 安装 wgcf
  ```bash
  curl -fsSL git.io/wgcf.sh | sudo bash
  ```
* 注册 WARP 账户 (将生成 `wgcf-account.toml` 文件保存账户信息)
  ```
  wgcf register
  ```
* 生成 Wire­Guard 配置文件 (`wgcf-profile.conf`)
  ```
  wgcf generate
  ```

生成的两个文件记得备份好，尤其是 `wgcf-profile.conf`，万一未来工具失效、重装系统后可能还用得着。

---

6.编辑 WireGuard 配置文件

这里默认的情况是服务器都有IPV4。

将配置文件中的节点域名 `engage.cloudflareclient.com` 解析成 IP。不过一般都是以下两个结果：

```
162.159.192.1
2606:4700:d0::a29f:c001
```

将配置文件中的 `engage.cloudflareclient.com` 替换为 `162.159.192.1`，并删除 `AllowedIPs = 0.0.0.0/0`。即配置后的文件如下图：

![image.png](https://tuchuang.frank2019.me/uploadImages/104/160/18/227/2021/04/05/21/41/789a94da-97f6-4358-a2e0-f2dac9d3d018.png)

> 原理：`AllowedIPs = ::/0`参数使得 IPv6 的流量均被 Wire­Guard 接管，让 IPv6 的流量通过 WARP IPv4 节点以 NAT 的方式访问外部 IPv6 网络

---

7.启用 WireGuard 网络接口

* 将 Wire­Guard 配置文件复制到 `/etc/wireguard/` 并命名为 `wgcf.conf`。
  ```
  sudo cp wgcf-profile.conf /etc/wireguard/wgcf.conf
  ```
* 开启网络接口（命令中的 `wgcf` 对应的是配置文件 `wgcf.conf` 的文件名前缀）。
  ```
  sudo wg-quick up wgcf
  ```

执行执行`ip a`命令，此时能看到名为`wgcf`的网络接口

执行以下命令检查是否连通。同时也能看到正在使用的是 Cloud­flare 的网络。

IPv4 Only VPS

```
curl -6 ip.p3terx.com
```

IPv6 Only VPS

```
curl -4 ip.p3terx.com
```

测试完成后关闭相关接口，因为这样配置只是临时性的。

```
sudo wg-quick down wgcf
```

正式启用 Wire­Guard 网络接口

```
# 启用守护进程
sudo systemctl start wg-quick@wgcf
# 设置开机启动
sudo systemctl enable wg-quick@wgcf
```

WARP 的情况有点特殊，现实的情况有可能是：

IPv4 Only 服务器优先通过原来的 IPv4 网络去访问外部网络。
IPv6 Only 服务器优先通过原来的 IPv6 网络去访问外部网络。

所以根据实际的需求就要手动去设置优先级。

IPv4 优先

编辑 `/etc/gai.conf` 文件，在末尾添加下面这行配置：

```
precedence ::ffff:0:0/96  100
```

一键添加命令如下：

```
# IPv4 优先
grep -qE '^[ ]*precedence[ ]*::ffff:0:0/96[ ]*100' /etc/gai.conf || echo 'precedence ::ffff:0:0/96  100' | sudo tee -a /etc/gai.conf
```

IPv6 优先

编辑 `/etc/gai.conf` 文件，在末尾添加下面这行配置：

```
label 2002::/16
```

一键添加命令如下：

```
# IPv6 优先
grep -qE '^[ ]*label[ ]*2002::/16[ ]*2' /etc/gai.conf || echo 'label 2002::/16   2' | sudo tee -a /etc/gai.conf
```

验证优先级

执行 `curl ip.p3terx.com` 命令，显示 IPv4 地址则代表 IPv4 优先，否则为 IPv6 优先。

PS：这里切记你的VPS要支持IPV6,并且给予IPV6权限

---

到这里就完成了Warp的配置工作。下面我们就来配置Xray

Xray这里我选用了Mack的一键脚本，很方便。

> https://github.com/mack-a/v2ray-agent

1.首先在脚本中选择IPV6人机验证，点击添加。

2.这时候 `/etc/v2ray-agent/xray/conf`   目录下会多出来一个`routing.json`文件，修改`geosite` 如下：

```
{
    "routing":{
        "domainStrategy": "IPOnDemand",
        "rules": [
          {
            "type": "field",
            "domain": [
              "geosite:google",
              "geosite:youtube"
            ],
            "outboundTag": "IP6-out"
          }
        ]
  }
}
```

重启后即可完成所有操作。这时候你访问Youtube就是使用WARP的IPV6了。也可以通过`https://ip.sb`来查看。

---

当然以上操作也适用于各种解锁流媒体，只要Warp不被Ban，理论上都是没问题的。

晚高峰测试了下速度，通过套Swarp的速度也还可以接受，youtube大概在6W左右，跑4K还是没问题的。（不过可惜了我这DMIT的优质线路）

![image.png](https://tuchuang.frank2019.me/uploadImages/104/160/18/227/2021/04/05/22/12/ed8d5912-9ab8-4f7e-af0d-1586ae869153.png)



  最有再次感谢TG上的朋友及mack脚本作者的帮助。

