title: 停止、删除所有的docker容器和镜像
date: '2019-10-30 04:08:42'
updated: '2020-07-22 16:54:07'
tags: [docker, 技术分享]
permalink: /articles/2019/10/30/1572404922106.html
---
![](https://img.hacpai.com/bing/20180504.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近在用Docker测试网站，发现老会忘记Docker的命令，年龄大了，就记录下来吧。

列出所有容器的ID
```
docker ps -aq
```
停止所有的容器
```
docker stop $(docker ps -aq)
```
删除所有的容器
```
docker rm $(docker ps -aq)
```
删除所有的镜像
```
docker rmi $(docker images -q)
```
删除所有不使用的镜像
```
docker image prune --force --all
```
删除所有停止的容器
```
docker container prune -f
```
复制文件
```
docker cp mycontainer:/opt/file.txt /opt/local/
docker cp /opt/local/file.txt mycontainer:/opt/
```
清理资源命令
```
docker system prune
```

