title: Ubuntu安装SS-Libev
date: '2020-03-01 07:21:08'
updated: '2020-07-22 15:46:13'
tags: [技术分享, ssmgr, SS]
permalink: /articles/2020/03/01/1583043668131.html
---
![](https://img.hacpai.com/bing/20180110.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近升级服务器，由于Ubuntu里的软件源并非最新版的SS，所以需要手动编译升级，记录下以免以后忘记。

#### 源码安装
1、准备编译环境
```
sudo apt install --no-install-recommends build-essential autoconf libtool \
         libssl-dev gawk debhelper dh-systemd init-system-helpers pkg-config asciidoc \
         xmlto apg libpcre3-dev zlib1g-dev libev-dev libudns-dev libsodium-dev \
         libmbedtls-dev libc-ares-dev automake
```
2、获取 shadowsocks-libev 源码， 并安装
```
sudo apt install git
git clone https://github.com/shadowsocks/shadowsocks-libev.git
cd shadowsocks-libev
git submodule update --init
./autogen.sh && ./configure --disable-documentation && make
sudo make install
```
3、 创建配置文件：
```
sudo mkdir /etc/shadowsocks-libev
sudo vi /etc/shadowsocks-libev/config.json
```

复制粘贴如下内容（注意修改密码“password”）：

```
{
     "server":"0.0.0.0",
     "server_port":8388,
     "local_port":1080,
     "password":"password",
     "timeout":600,
     "method":"aes-256-cfb" ,
     "fast_open": false
 }
```
4、创建 Shadowsocks-libev.service 配置文件
```
sudo vi /etc/systemd/system/shadowsocks-libev.service
```
复制粘贴：
```
[Unit]
Description=Shadowsocks-libev Server
After=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/ss-server -c /etc/shadowsocks-libev/config.json -u
Restart=on-abort

[Install]
WantedBy=multi-user.target
```
5、启动 Shadowsocks：
```
sudo systemctl start shadowsocks-libev
```
6、设置开机启动
```
sudo systemctl enable shadowsocks-libev
```
7、查询SS状态及获取帮助
```
ss-manager -h
```


