title: 更换博客系统BOLO
date: '2020-07-23 22:44:32'
updated: '2020-07-23 22:48:08'
tags: [技术分享, Bolo]
permalink: /articles/2020/07/23/1595515472630.html
---
![](https://b3logfile.com/bing/20180331.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

最近因为SOLO博客进行了一轮大更新。有些功能被废弃了。所以为了实现功能，我也将博客系统更换为BOLO了。BOLO博客基本就是SOLO的独立版，转换十分平滑。这里做个搭建记录方便自己的日后维护。
官方教程：
```
https://doc.stackoverflow.wiki/web/#/7?page_id=46
```
1.首先链接现有SOLO数据库，然后按照官方教程进行加表。
2.配置环境
用宝塔很简单，直接安装JAVA和Tomcat就可以了。
3.然后下载WAR包，解压到TOMCAT/ROOT目录下。
4.配置JAVA，默认端口为8080.然后配置，映射，会自动在网站端进行反代。
![image.png](https://b3logfile.com/file/2020/07/image-767b63ab.png)
5.配置数据库文件local文件，填写现在的数据库用户和密码。
6.剩下就是测试能否成功访问。其实官方文档介绍的已经很详细了。
7.修改主题Footer，Logo，以及Start，Search文件。
到此基本完成了平滑切换，除了分类要重新调整，其他都是正常使用的，而且作者加了一些很实用的功能，感觉更贴心一些。其他功能还在慢慢体验。


