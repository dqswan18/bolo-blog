title: 删除所有Aliyun监控进程，屏蔽云盾功能
date: '2019-10-16 22:36:09'
updated: '2020-09-01 21:12:33'
tags: [阿里云, 阿里云盾, VPS, dd]
permalink: /articles/2019/10/16/1571236569200.html
---
![](https://img.hacpai.com/bing/20190525.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

近日购入阿里云轻量应用服务器准备用做个人使用，但是真的不想被人到处监控，所以象征性的删除了阿里云上的监控和云盾。其实也只是心里作用，反正我也不用作非法途径，只是想图个清净而已。

#### 卸载阿里云盾监控：

wget http://update.aegis.aliyun.com/download/uninstall.sh
chmod +x uninstall.sh
sudo ./uninstall.sh
wget http://update.aegis.aliyun.com/download/quartz_uninstall.sh
chmod +x quartz_uninstall.sh
sudo ./quartz_uninstall.sh

#### 删除残留：

sudo pkill aliyun-service
sudo rm -fr /etc/init.d/agentwatch /usr/sbin/aliyun-service
sudo rm -rf /usr/local/aegis*


#### 屏蔽云盾 IP，用包过滤屏蔽如下IP：

iptables -I INPUT -s 140.205.201.0/28 -j DROP
iptables -I INPUT -s 140.205.201.16/29 -j DROP
iptables -I INPUT -s 140.205.201.32/28 -j DROP
iptables -I INPUT -s 140.205.225.192/29 -j DROP
iptables -I INPUT -s 140.205.225.200/30 -j DROP
iptables -I INPUT -s 140.205.225.184/29 -j DROP
iptables -I INPUT -s 140.205.225.183/32 -j DROP
iptables -I INPUT -s 140.205.225.206/32 -j DROP
iptables -I INPUT -s 140.205.225.205/32 -j DROP


#### 卸载云监控Java版本插件：


sudo /usr/local/cloudmonitor/wrapper/bin/cloudmonitor.sh stop

sudo /usr/local/cloudmonitor/wrapper/bin/cloudmonitor.sh remove

sudo rm -rf /usr/local/cloudmonitor

当然，如果时间充裕的话，最好还是DD个纯净版。只要有ROOT权限就可以了。

```
wget -N --no-check-certificate "https://raw.githubusercontent.com/chiakge/installNET/master/Install.sh" chmod +x Install.sh ./Install.sh
```


傻瓜操作，直接可以开始DD之旅了。

