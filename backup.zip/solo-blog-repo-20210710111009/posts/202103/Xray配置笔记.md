title: Xray配置笔记
date: '2021-03-14 22:20:21'
updated: '2021-03-15 15:37:41'
tags: [技术分享, Xray]
permalink: /articles/2021/03/14/1615731621309.html
---
![](https://b3logfile.com/bing/20171217.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

什么是Xray协议？

> 其实简单的来理解，V2RAY是一个内核，而XRAY也是一个内核。
> 形象的比喻一下，你可以把VLESS或是VMESS协议理解为汽油，而VLESS+TLS+WS或是VMESS+++等等等等其他的各种V2RAY的协议，理解为燃油宝或是燃油添加剂，只是为了让汽油更好的燃烧或是爆发力更强。
> 而XRAY内核或是V2RAY内核，你可以理解内核为发动机，V2RAY是老款的发动机，而XRAY是新款的发动机。新款的发动机支持XTLS的汽油，并且向下兼容原来的各种汽油以及燃油宝，然而老款的发动机仅仅只是支持原先的各种汽油和燃油宝。所以嘛，选新不选旧，新发动机的各项指标以及兼容程度肯定是值得让人选择的。

最近Xray+Xlts服务以对服务器配置要求低，以及速度快成为技术圈热议的话题，于是我也利用周末对我的服务器进行了Xray配置。实测表现果然没让人失望。
在同等网络环境下，Xray协议跑Youtube均在10W+
![image.png](https://tuchuang.frank2019.me/uploadImages/104/160/18/227/2021/03/15/15/29/2d982f69-c8a5-402d-a060-8a0b8a99ba31.png)

---



而SS只有8W左右
![image.png](https://tuchuang.frank2019.me/uploadImages/104/160/18/227/2021/03/15/15/32/8aac094c-e366-44b7-a277-a7958e4d2472.png)

如果有软路由的情况下，Xray才能完全的释放性能，而且安全性更是目前最优的方案。Xray目前核心已经更新到1.4，适配情况也越来越好，相信这对于科学上网是革命性的更新，因为强大且智能的回落及分流给了GFW更高的探测分析门槛。
当然在搭建过程中也参考了很多教程，这里做个笔记，以免忘记。

Xray小白教程：https://xtls.github.io/documents/level-0/
一键脚本：https://github.com/mack-a/v2ray-agent
相关服务器端及客户端教程：https://www.jamesdailylife.com/xray_software
V2rayN新版教程：https://www.jamesdailylife.com/new_v2rayn-windows

目前解决方案越来越多，但是也要求的技术性越来越强，所以理论上来说门槛是提高了的，不过好在诸多大神提供了各式各样的脚本方案，真心希望有一天连接世界不再那么曲折。

