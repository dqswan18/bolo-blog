title: Ubuntu 16.04 升级到 18.04 LTS 笔记
date: '2019-09-24 03:45:16'
updated: '2020-07-22 15:55:30'
tags: [VPS, 技术分享, Ubuntu]
permalink: /articles/2019/09/24/1569293116012.html
---
![](https://img.hacpai.com/bing/20180628.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 更新Ubuntu 16.04

在升级之前，先更新当前的16.04至最新状态。建议升级之前更新/升级所有已安装的软件包。

#### 首先更新APT源和软件包至最新
```
sudo apt update && sudo apt dist-upgrade && sudo apt autoremove
```


#### 安装和配置Ubuntu update manager

更新完组件后，运行以下命令安装update-manager-core
```
sudo apt install update-manager-core
```


打开update-manager配置文件

sudo nano /etc/update-manager/release-upgrades

确保设置为**Prompt=lts**  

#### 执行升级命令
```
sudo do-release-upgrade -d
```


出现升级提示时，全部选择y

等待所有的软件包下载...安装...到重启... 

当所有操作执行完毕后，系统就升级到最新的Ubuntu 18.04 LTS版本了。
