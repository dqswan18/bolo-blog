title: VPS常用脚本
date: '2020-03-25 08:21:20'
updated: '2020-07-22 15:44:50'
tags: [技术分享, VPS]
permalink: /articles/2020/03/25/1585120880298.html
---
![](https://img.hacpai.com/bing/20190228.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 综合测试脚本

※这类脚本是综合测试VPS基础信息、硬盘IO、带宽和网络延迟等项目的一键式脚本，主要有以下几个

1. 秋水逸冰大佬的Bench.sh脚本

特点：

1. 显示当前测试的各种系统信息；
2. 取自世界多处的知名数据中心的测试点，下载测试比较全面；
3. 支持 IPv6 下载测速；
4. IO 测试三次，并显示平均值。

使用：

wget -qO- bench.sh | bash
#或者
curl -Lso- bench.sh | bash
#或者
wget -qO- 86.re/bench.sh | bash
#或者
curl -so- 86.re/bench.sh | bash

Github地址：[https://github.com/teddysun/across/blob/master/bench.sh](https://github.com/teddysun/across/blob/master/bench.sh)
<br>

2. 老鬼大佬的SuperBench测试脚本

这个脚本是在基于秋水大佬脚本的基础上，加入了独服通电时间，服务器虚拟化架构等内容

特点：

1. 改进了显示的模式，基本参数添加了颜色，方面区分与查找。
2. I/O测试，更改了原来默认的测试的内容，采用小文件，中等文件，大文件，分别测试IO性能，然后取平均值。
3. 速度测试替换成了 Superspeed 里面的测试，第一个默认节点是，Speedtest 默认，其他分别测试到中国电信，联通，移动，各三个不同地区的速度。

使用方法

```
wget -qO- --no-check-certificate https://raw.githubusercontent.com/oooldking/script/master/superbench.sh | bash
```

#或者

```
curl -Lso- -no-check-certificate https://raw.githubusercontent.com/oooldking/script/master/superbench.sh | bash
```

Github：[https://github.com/oooldking/script/blob/master/superbench.sh](https://github.com/oooldking/script/blob/master/superbench.sh)
<br>
3. Zbench

脚本由漏水和kirito，基于Oldking大佬 的 SuperBench，然后加入Ping以及路由测试的功能，还能生成测评报告，分享给其他人查看测评数据

使用方法

#中文版

```
wget -N --no-check-certificate https://raw.githubusercontent.com/FunctionClub/ZBench/master/ZBench-CN.sh && bash ZBench-CN.sh
```

#英文版

```
wget -N --no-check-certificate https://raw.githubusercontent.com/FunctionClub/ZBench/master/ZBench.sh && bash ZBench.sh
```

<br>

4.回城路由测试

```
wget https://raw.githubusercontent.com/nanqinlang-script/testrace/master/testrace.sh
bash testrace.sh
```
