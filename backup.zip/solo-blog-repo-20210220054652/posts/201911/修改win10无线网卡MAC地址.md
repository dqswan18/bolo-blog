title: 修改win10无线网卡MAC地址
date: '2019-11-26 08:39:07'
updated: '2020-07-22 15:53:23'
tags: [技术分享, Win10]
permalink: /articles/2019/11/26/1574753947767.html
---
![](https://img.hacpai.com/bing/20180519.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

  最近公司的一台电脑连接WIFI网速十分的慢，其他电脑确都正常，于是开始了我的排查之旅。
1.驱动问题？驱动重新安装，并且连接其他WIFI网速正常。---排除
2.硬件损坏？基于第一点，所以自然就排除了。--排除
3.系统BUG？重新安装win10，并且升级至最新的1909，连接公司路由仍然不行。--排除

综合以上，我觉得应该是路由的问题，检查路由设置一切正常，也没有拉入黑名单什么的操作。所以严重怀疑是IP和MAC地址的问题。
由于是无线网络，win10里没有相应的选项，所以要通过注册表进行更改。记录如下：

win+R快捷键->输入regedit打开注册表

定位到 

HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\ Control\Class

\{4D36E972-E325-11CE-BFC1-08002BE10318}\
![9bf3a6a2f5d09d22e375494e649335f3805.jpg](https://img.hacpai.com/file/2019/11/9bf3a6a2f5d09d22e375494e649335f3805-8d424b88.jpg)
上图中的00XX就是代表一个网卡,从右边的DriverDesc中找到无线网卡所属的分类。
比如我的无线网卡所在的目录编号为 0002 ,就打开 0002 / Ndi /Params 中,
如果其中没有NetworkAddress这个项,我们就新建 -> 项,然后重命名为NetworkAddress
然后找到我们有线网卡的相同路径
![image.png](https://img.hacpai.com/file/2019/11/image-6e788a12.png)
把这些数值原封不动的复制到新的路径中
然后在进入网络适配器配置的高级就可以看到了。
![image.png](https://img.hacpai.com/file/2019/11/image-bdc13620.png)

修改成自己想要的MAC地址，这里要注意修改的无线网卡的MAC地址应该注意修改时第二个MAC数值只能是2 6 A E其中之一 否则无效。同理，无线网络MAC也一样。
即只能是x2-xx-xx-xx-xx或x6-xx-xx-xx-xx-xx等。

PS:但是非常遗憾，问题仍然没有得到解决。
