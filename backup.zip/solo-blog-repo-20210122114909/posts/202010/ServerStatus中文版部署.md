title: ServerStatus中文版部署
date: '2020-10-28 04:36:50'
updated: '2020-10-28 04:36:50'
tags: [docker, 技术分享, 宝塔]
permalink: /articles/2020/10/28/1603856210593.html
---
![](https://b3logfile.com/bing/20181109.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近服务器经常出现失联的情况，为了更好的监控服务器准备在所有服务器上都加上探针，以便更好的管理Vps。
对于探针没有过多的要求，就是要轻量，便捷，功能不需要太复杂。正巧，朋友推荐ServerStatus，都能满足我以上的诉求，而且作者已经更新3年了。程序也相对稳定。

> https://github.com/cppla/ServerStatus  官方地址

搭建过程：

1.安装Docker，开放相应安全策略组。

2.服务器端执行一键安装命令，中间的Config.json可以挂载到本地，便于修改。端口80自行调整为空闲端口。

```
docker run -d --restart=always --name=serverstatus -v ~/config.json:/ServerStatus/server/config.json -p 80:80 -p 35601:35601 cppla/serverstatus
```



3.DNS解析个想用的域名，在宝塔上分配域名，进行反代设置。

4.配置客户端，注意USER要对应每个客户端独有编号，否则会重复显示。

```
wget --no-check-certificate -qO client-linux.py 'https://raw.githubusercontent.com/cppla/ServerStatus/master/clients/client-linux.py' && nohup python client-linux.py SERVER=45.79.67.132 USER=s04  >/dev/null 2>&1 &
```

5.修改服务器端的Config，密码推荐用默认的，Username就是每台服务器的代号。这样可以一键启动客户端。



>

```
"username": "s01",
"name": "Vultr",
"type": "KVM",
"host": "host1",
"location": "Japan",
"password": "XXXXXXX"
```

至此就完成了部署工作，配置完后重启Docker即可。非常简单，傻瓜。

Demo演示：https://monitor.frank2019.me/

