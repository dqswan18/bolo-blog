title: 安装SHADOWSCOCKS-MANAGER
date: '2019-09-04 08:56:15'
updated: '2020-07-22 16:49:49'
tags: [技术分享, 心情随笔, SS]
permalink: /articles/2019/09/04/1567580175121.html
---
![](https://img.hacpai.com/bing/20171223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

研究了两天如何搭建，最终在大神大袋鼠的帮忙下终于完成了，看到文章的小伙伴可以去大神大袋鼠的博客转转膜拜下。他博客地址是：https://muguang.me/

好了，废话不多说了，我们言归正穿。下面我把流程简单梳理下，给自己做个笔记。

以下所有配置环境均为centos7，其他系统操作类似。

这里可能会用的apt指令，所以先安装apt

```
yum install apt

sudo apt-get update
```

1.安装配置shadowsocks libev，这个教程满大街了。

```
wget --no-check-certificate -O shadowsocks-all.sh https://raw.githubusercontent.com/teddysun/shadowsocks_install/master/shadowsocks-all.sh
chmod +x shadowsocks-all.sh
./shadowsocks-all.sh 2>&1 | tee shadowsocks-all.log
```

2.安装node.js npm，注意这里必须要用10.0

```
curl -sL https://rpm.nodesource.com/setup_10.x | bash -
```

3.安装shadowsocks-manager ，在安装目录下  用npm安装sqlite3

```
sudo npm i -g shadowsocks-manager --unsafe-perm npm install sqlite3 --unsafe-perm  
npm i -g shadowsocks-manager  
npm install sqlite3
```

4.安装 redis-server 并设置进程常驻

```
$sudo apt-get update  
$sudo apt-get install redis-server
```

然后接下来就是设置密码，然后在webgui.yml后面插入

```
redis:

 host: '127.0.0.1'

 password: '123456'

 db: 0
```

5.按照官方文档写 ss-manager 的配置。这里要先配置SS.yml，在配置webgui.yml，目录为：

`/root/.mmsgr`

`ss.yml`

```
type: s shadowsocks:    
address: 127.0.0.1:1234 #shadowsocks的管理端口  
manager: address: 0.0.0.0:4321 #这个 address 参数会让程序监听一个 tcp 端口，用于接收 webgui 发送过来的控制命令    
password: 'XXXX' #webgui添加节点时的密码 db: 'ss.sqlite'

webgui.yml

type: m  
 manager:  
 address: 这里填写你的IP  
 password: '密码'  
 plugins:  
 flowSaver:  
 use: true  
 user:  
 use: true  
 account:  
 use: true  
 email:  
 use: true  
 type: 'smtp'  
 username: '邮箱地址'  
 password: '密码'  
 host: 'smtp.gmail.com'  
 webgui:  
 use: true  
 host: '0.0.0.0'  
 port: '80'  
 site: '网站'  
 # icon: 'icon.png'  
 # skin: 'default'  
 # googleAnalytics: 'UA-xxxxxxxx-x'  
 # gcmSenderId: '476902381496'  
 # gcmAPIKey: 'AAAAGzddLRc:XXXXXXXXXXXXXX'  
 db: 'webgui.sqlite'  
 从 0.30 开始需要配置 redis  
 redis:  
 host: '127.0.0.1'  
 port: 6379  
 password: ''  
 db: 0
```

6.安装 pm2，设置 ss-manager 进程常驻

```
 npm i -g pm2  
 pm2 --name s1 -f start ssmgr -x -- -c /root/.ssmgr/ss.yml -r  
 pm2 --name s2 -f start ssmgr -x -- -c /root/.ssmgr/webgui.yml  
 pm2 startup #将pm2写入系统service开机启动  
 pm2 save #保存pm2当前守护进程的列表
```

7.开放防火墙，这里你分配多少端口，就开放多少防火墙。

```
sudo firewall-cmd --zone=public --add-port=3000/tcp --permanent  
sudo firewall-cmd --reload  
```
 检查防火墙  
```
 firewall-cmd --list-all
```

8.更新版本，这里需要服务器和每个节点都要运行更新命令，更新完毕后重新启动即可。
```
sudo npm i -g shadowsocks-manager --unsafe-perm
```
```
cd .ssmgr
sh.start.sh
```
流程大概就是这些了，如果有不明白的可以留言评论，体验网站：frank2019.xyz

最后再次感谢[大袋鼠](https://muguang.me/)。
