title: GCP谷歌云开启SSH客户端root登录
date: '2019-11-18 05:03:37'
updated: '2020-07-22 15:53:35'
tags: [VPS, Ubuntu, Gcp, 技术分享]
permalink: /articles/2019/11/18/1574049817790.html
---
![](https://img.hacpai.com/bing/20171121.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

最近从Xshell改为了FinaShell，但是发现在登陆谷歌云的时候不能用root登陆。这里提供一个解决办法，这样以后就可以通过任何工具以root权限直接登陆谷歌云，不用在用默认面板进行登陆了。

#### 浏览器登陆，拿到ROOT权限
```
sudo -i
```
#### 输入命令编辑ssh配置文件
```
vi /etc/ssh/sshd_config
```
#### 找到下面的内容，并修改
```
PermitRootLogin  yes 
PasswordAuthentication yes (no改为yes，如果前面有#注释的去掉#)
```
#### 输入命令重启ssh
```
service sshd restart
```
#### 设置新root密码
```
passwd root
```

