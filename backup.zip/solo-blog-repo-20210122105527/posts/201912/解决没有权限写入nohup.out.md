title: 解决没有权限写入nohup.out
date: '2019-12-17 04:08:23'
updated: '2020-07-22 16:52:42'
tags: [nohup, 技术分享, Ubuntu, VPS]
permalink: /articles/2019/12/17/1576552103309.html
---
![](https://img.hacpai.com/bing/20190207.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

更新完SOLO博客后，需要使用nohup在后台一直运行。但是当服务器重启后，重新运行该命令后会出现
```
# nohup: ignoring input and appending output to 'nohup.out'
```
这个是因为没有权限导致日志无法写入到nohup.out文件里。网上有很多教程，这里做哥搬运，方便自己以后处理该类问题
解决方法比较简单，直接重定向错误信息到linux系统下的“空洞”里即可。

```
nohup commd > /dev/null 2>&1 &
```

正常输出和错误信息都不显示，把标准输出和标准错误都重定向到/dev/null，

```
# ls 1>/dev/null 2>/dev/null
```

还有一种做法是将错误重定向到标准输出，然后再重定向到 /dev/null，例如：

```
# ls >/dev/null 2>&1
```

顺序不能更改，否则达不到想要的效果，先将标准输出重定向到 /dev/null，

然后将标准错误重定向到标准输出，

由于标准输出已经重定向到了/dev/null，因此标准错误也会重定向到/dev/null，

使用nohup命令由于输出nohup.out的路径没有写入权限

使用Linux重定向的方法，将nohup.out重定向至一个有写入权限的路径，或丢到/dev/null中。

```
nohup ./program >/dev/null 2>/dev/null &
```

或者  

```
nohup ./program >/dev/null 2>&1 &
```

