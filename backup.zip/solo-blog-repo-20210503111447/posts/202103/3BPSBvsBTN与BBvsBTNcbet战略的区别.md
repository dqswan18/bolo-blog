title: 3BP SB vs BTN与BB vs BTN cbet战略的区别
date: '2021-03-07 14:19:26'
updated: '2021-03-07 14:19:26'
tags: [德州范围, 德州策略, 德州扑克]
permalink: /articles/2021/03/07/1615097966208.html
---
![](https://b3logfile.com/bing/20190307.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

本位着重于分析【SB vs BTN 与BB vs BTN 在3bet底池中 cbet策略的不同】

使用1755flop*2的聚合报告。

分析流程：观察SB vs BTN 与BB vs BTN 在3bet底池中 cbet策略的聚合报告进行分析，观察特征。 针对这些特征进行原因假设，再对假设进行论证。

阅读后能解决的问题：

1. SB vs BTN 与BB vs BTN 在3bet底池中 cbet策略有哪些不同？分别有什么特征？
2. 造成这些差别的原因有哪些？
3. 通过什么办法能够论证1和2？

**SOLVER设定**

Pot:20bb 后手有效：90bb SPR约4.5

Bet size：33%，57%，80% 三种

范围：

![](https://pic1.zhimg.com/80/v2-d95506886e23c2af191b9f8796490468_720w.jpg)![](https://pic3.zhimg.com/80/v2-6b608a04b93e30d141b0ac69765350fe_720w.jpg)**聚合报告分析结果 行动频率**

首先，通过聚合报告观察OOP的check频率。

![](https://pic1.zhimg.com/80/v2-3c477e6cd44eb90228851ce8d9893a8c_720w.jpg)这里为聚合报告的部分截图，左边为BB 3bet，右边为SB 3bet。比如红框中就表示在2h2d2c的公共面上，BB有20%频率check，SB有大约4.5%的频率需要check。

**尝试计算check频率的差值**

之后，我们来用【BB的check频率-SB的check频率】尝试计算两者check频率的差值。如上述2h2d2c的面上，差值即为20.02-4.55=15.47。

在1755个flop上执行此计算，得出结果如下图。

![](https://pic2.zhimg.com/80/v2-cdd978de6091cbfa980cd89ce6ac78b1_720w.jpg)![](https://pic1.zhimg.com/80/v2-401406437002c4ef5f26ee4442627854_720w.jpg)![](https://pic3.zhimg.com/80/v2-0ed1f9570bcd98772aef848ab987f3de_720w.jpg)横轴：FLOP的high card（A=14 K=13 Q=12）

纵轴：check频率差=BB的check频率-SB的check频率（点越靠上，表明与SB相比，BB的check频率越高）

点的颜色：

红色：明三条 绿色：公对 蓝色：其他

**Check频率差的特征**

![](https://pic2.zhimg.com/80/v2-cdd978de6091cbfa980cd89ce6ac78b1_720w.jpg)图1为天花面的分布图

**特征1：在天花面上，总体来看BB的check频率更高。但是在A high面上SB的check频率却更高。**

![](https://pic1.zhimg.com/80/v2-401406437002c4ef5f26ee4442627854_720w.jpg)![](https://pic3.zhimg.com/80/v2-0ed1f9570bcd98772aef848ab987f3de_720w.jpg)之后是2tone和干燥面的分布图。

**特征2:** **在2tone或者干燥面上，J high面上BB的check频率更高，7-6 high面上 明显SB的check频率更高。**

总体来看，check频率的最大差值约为40%，最小为-50%， 受flop的影响非常大。

这里以干燥面为对象，将-25%以下或25%以上的公共面抽出，形成柱状图。

![](https://pic4.zhimg.com/80/v2-8ac080ebecf197475b0bb7bd0a3808a3_720w.jpg)![](https://pic1.zhimg.com/80/v2-2fc71c4a00c4ae33553ef5fa7372a7fc_720w.jpg)第一张图，是check频率差在-25%以下，第二张图是check频率差在25%以上时对应flop的抽出展示。蓝色表示无公对，绿色表示公对面。

通过观察图1的横轴，可以清楚地发现全部都是顺面以及6或7的公对面。

**特征3：在6或7的公对面上，相对于BB，SB的check更多。**

**特征4：543，A32,743等顺面上，SB的check频率要高于bb。**

通过观察第二张图，发现几乎都是AKx的面。

**特征5：AKx的公共面上，BB的check更多**

**思考原因**

![](https://pic2.zhimg.com/80/v2-f23858eef16ad1106af08f139dc5df45_720w.jpg)针对这3个假设，进行逐一验证。

首先，验证假设1， 这里整理了SB 3bet BTNc和BB 3bet BTNc 的范围中，同花手牌组合的占比。（靠右大片紫色为off suited）

![](https://pic2.zhimg.com/80/v2-9d39e46e261c7dfbf42e2d840fcf811d_720w.jpg)**得出的结果为：**

SB 3bet范围中同花组合占比42%，BTNc 51%， 差为9%

BB 3bet范围中同花组合占比43%，BTNc 58%， 差为15%

**显然，BB vs BTN时 IP 的call range中同花组合更多。**

接下来，着重于绿色部分Axs的占比。SB对BTN的情况下，双方的占比都差不多（绿色几乎一样大）。BB对BTN的情况下，BTN的Axs占比更多。 **这是因为SB的3bet range里有ATs-A7s，BB的3bet范围里没有这些组合。**

在FLOP AXY天花面上，上图中的红色部分表示有可能形成flush的KXs组合。

**SB 3bet范围中Kx同花组合占比23%，BTNc 33%， 差为10%**

**BB 3bet范围中Kx同花组合占比33%，BTNc 38%， 差为5%**

由此得出，IP 范围中KXs以下的同花组合更多。

这可能就是导致特征1的原因。

**特征1：在天花面上，总体来看BB的check频率更高。（* BTN 范围中suited组合更多）**

**但是在A high面上SB的check频率却更高。（*BTN KXs suited组合更多）**

**假设2的验证**

**【范围中J，7，6的比例存在异常？】 这里列出了所有的数字组合。**

![](https://pic4.zhimg.com/80/v2-4dd46eb5e2dd0458a2f7878715d728af_720w.jpg)上面2张图中图1为SB vs BTN，图2为BB vs BTN。 很明显，SB对抗BTN时，BTN范围中6和7的组合占比更高（红框）。紫色框中显示SB的Jx组合更多。BB对BTN时并没有SB对BTN时那么大的范围差，所以这应该是造成特征2 和特征3 的原因。

**特征2：在2tone或者干燥面上，J high面上BB的check频率更高，7-6 high面上 明显SB的check频率更高。（*SB的Jx组合更多）**

**特征3：在6或7的公对面上，相对于BB，SB的check更多。（BTN范围中6和7的组合占比更高）**

**假设3的验证**

76,65,54等连接牌以及AK的占比存在异常？

这里尝试将range的差值可视化。

![](https://pic4.zhimg.com/80/v2-e059d95c55d47bc7adb960d7c5c6d313_720w.jpg)图中蓝色表示OOP中占比更高，红色表示IP中占比更高。

SB vs BTN时 98s-54s的组合 BTN更多，BB vs BTN时AA，KK，AK这些组合BB里更多。Ats-A4s 及AJo这些组合BTN更多。

