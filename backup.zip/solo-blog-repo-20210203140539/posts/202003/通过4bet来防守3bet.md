title: 通过4bet来防守3bet
date: '2020-03-01 20:04:27'
updated: '2020-07-22 22:45:51'
tags: [德州范围, 德州策略, 德州扑克]
permalink: /articles/2020/03/01/1583064267189.html
---
![](https://img.hacpai.com/bing/20190813.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

当我们的公开加注遭遇到对手的 3bet 时，那些我们希望继续游戏的牌可以进行 4bet，也可以跟注。今天来谈一谈我们应该如何构建一个 4bet 的范围。注意，今天我们谈到的 4bet 是指我们的 RFI 遭遇对手 3bet 时，进行的 4bet, **而不是 cold 4bet **(cold 4bet 是指当一个对手 RFI 另一个对手进行 3bet, 我们进行 4bet)**。**



首先明确一下， 我们为什么要对对手的 3bet 进行 4bet, 理由有以下两种：

理由一**(主要理由)**, 为了在赢取底池时赢得一个大底池，俗称 value 4bet。当我们有一手翻牌前胜率高的牌时，通过在翻牌前将底池变大(SPR 变小)，使得我们在后面几条街榨取价值和决策变得更加容易，同样由于底池的膨胀，我们榨取的价值也会变多。

理由二(**也为了理由一服务**), 为了拒绝对手的底池权益， 俗称 bluff 4bet。例如我们使用 A♥️5♥️ 进行了一个 4bet，对手的底牌是 A♠️Q♣️，最终无奈弃牌，那么虽然对手对抗我们有高于 70% 的胜率，但是我们通过 4bet 拒绝了其实现底池权益的机会。



通过观察外国职业牌手兼教练 educa-Poker 给出的 6-max 翻牌前建议，4bet 范围是使用的一个**极化**的范围，那么我们应该如何去构建理由一和理由二的手牌呢？

理由一的手牌范围构建较简单，通常来说由我们进行 RFI 手牌的顶端范围构成，通常包括 AA，KK。对抗一些支付能力较强且不愿意弃牌给 4bet 的玩家，QQ，AKs，AKo 都是不错的候选手牌，如果对手跟注倾向严重且非常松，有时候甚至可以加入 AQs 和 JJ。但总体来说 4bet 的价值范围不应该超过 (JJ+, AQs+, AKo)。

理由二的手牌选择稍微有一些难，通常由三种牌型构成：

1. 同色 Ace，选择这样的牌型主要原因：第一，由于阻断牌 (blocker) 效应，当我们有一张 Ace 时，对手拥有 AA 的组合数从 6 变成了 3, 减少了 50%。对手有 AKs, AKo 的组合数从 16 降到了 12，减少了 25%。第二，这类牌具有一定的坚果潜力，同色 Ace 可以在翻牌后形成坚果同花，小的同色 Ace，A2s ~ A5s, 可以形成最小的顺子 A2345。第三，有时候这些牌集中顶对 A 可以在对抗 QQ，KK 时赢得底池实现其底池权益。

2. 中等同色连张，例如 54s ~ 98s，选择这样的牌型主要原因是：如果我们只用价值范围和同色 Ace 做 4bet, 那么在一些中等的牌面，例如说 9♥️ 8♥️ 6♠️，我们毫无坚果优势，因为我们没有 set，没有 two pair，最强的牌是超对，对手可以给我们极大的压力，特别是在深筹码 (250BB+) 的情况下，例如通过不断的进攻，例如 overbet, check raise。在 A high 的牌面，我们的范围又包括了太多的顶对，使得我们容易阅读。我们需要这样的牌在一些只有中张和低张的翻牌面做平衡。

3. 有 blocker 的非同色高张，blocker 一般是 A 或者 K，例如 AJo, KQo, AQo，这些牌有 A 会阻断 AA，AK。有 K 会阻断 KK，AKo，这些牌在一些情况下 (例如 UTG vs MP 3bet, MP vs CO 3bet) 太差以至于不能去跟注一个 3bet，有时候可以使用这些牌进行 4bet bluff。



当我们进行 4bet 时，我们应该考虑的因素主要包括：

1. 对手进行 3bet 的范围宽度，越宽的 3bet 范围我们应该使用越宽的 4bet 范围。

2. 对手的弃牌率，如果弃牌率高，我们应该增加诈唬范围，反之如果对手弃牌率低，我们应该减少诈唬范围，增加价值范围。（通常这个针对有漏洞的对手才需要考虑因素 2）



以下是一些实例，这里我们将列出对抗 solid 对手的 3bet 的场景：

例子一，MP 3bet UTG，CO 3bet MP。这两种 3bet 范围通常都是非常紧的(由于后面未行动的玩家较多，且 UTG/MP 的 RFI 范围非常紧，这里不太适合 3bet 频率过高)。所以我们应该 4bet 的范围应该相对紧，这几乎所有 4bet 范围中最紧的两种，我们应该的策略应该不偏出以下给出的策略太多（图中红色表示 4bet, 绿色表示 call 3bet)

<figure data-size="normal" style="margin: 1.4em 0px; color: rgb(26, 26, 26); font-family: -apple-system, BlinkMacSystemFont, &#34;Helvetica Neue&#34;, &#34;PingFang SC&#34;, &#34;Microsoft YaHei&#34;, &#34;Source Han Sans SC&#34;, &#34;Noto Sans CJK SC&#34;, &#34;WenQuanYi Micro Hei&#34;, sans-serif; font-size: medium; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;"><img src="https://pic1.zhimg.com/80/v2-c141f91763fd54b8eb299fa906c58464_1440w.jpg" data-size="normal" data-rawwidth="531" data-rawheight="533" class="origin_image zh-lightbox-thumb lazy" width="531" data-original="https://pic1.zhimg.com/v2-c141f91763fd54b8eb299fa906c58464_r.jpg" data-actualsrc="https://pic1.zhimg.com/v2-c141f91763fd54b8eb299fa906c58464_b.jpg" data-lazy-status="ok" style="display: block; max-width: 100%; margin: 0px auto; cursor: zoom-in; background-color: transparent; animation: 0.5s ease-in 0s 1 normal none running fxRichTextFadeIn;"/><figcaption style="margin-top: 0.66667em; padding: 0px 1em; font-size: 0.9em; line-height: 1.5; text-align: center; color: rgb(153, 153, 153);">UTG RFI vs MP 3bet</figcaption></figure>

<figure data-size="normal" style="margin: 2.24em 0px 1.4em; color: rgb(26, 26, 26); font-family: -apple-system, BlinkMacSystemFont, &#34;Helvetica Neue&#34;, &#34;PingFang SC&#34;, &#34;Microsoft YaHei&#34;, &#34;Source Han Sans SC&#34;, &#34;Noto Sans CJK SC&#34;, &#34;WenQuanYi Micro Hei&#34;, sans-serif; font-size: medium; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;"><img src="https://pic3.zhimg.com/80/v2-6ad514bdb0092e89a8b2ec1c0c6d035a_1440w.jpg" data-size="normal" data-rawwidth="533" data-rawheight="534" class="origin_image zh-lightbox-thumb lazy" width="533" data-original="https://pic3.zhimg.com/v2-6ad514bdb0092e89a8b2ec1c0c6d035a_r.jpg" data-actualsrc="https://pic3.zhimg.com/v2-6ad514bdb0092e89a8b2ec1c0c6d035a_b.jpg" data-lazy-status="ok" style="display: block; max-width: 100%; margin: 0px auto; cursor: zoom-in; background-color: transparent; animation: 0.5s ease-in 0s 1 normal none running fxRichTextFadeIn;"/><figcaption style="margin-top: 0.66667em; padding: 0px 1em; font-size: 0.9em; line-height: 1.5; text-align: center; color: rgb(153, 153, 153);">MP RFI vs CO 3bet</figcaption></figure>

例子二：SB 3bet BTN，由于 SB 采用的是线性范围 3bet，且是对一个较宽的范围做的 3bet，那么他的 3bet 范围也会较宽 (标准频率 17.5%)。因此我们在 BTN 的 4bet 范围应该调整，且我们有位置，所以相应的我们的 4bet 范围也应该变得宽一些。

<figure data-size="normal" style="margin: 1.4em 0px; color: rgb(26, 26, 26); font-family: -apple-system, BlinkMacSystemFont, &#34;Helvetica Neue&#34;, &#34;PingFang SC&#34;, &#34;Microsoft YaHei&#34;, &#34;Source Han Sans SC&#34;, &#34;Noto Sans CJK SC&#34;, &#34;WenQuanYi Micro Hei&#34;, sans-serif; font-size: medium; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;"><img src="https://pic1.zhimg.com/80/v2-aee1af9c3b884c3314f5071db827cfa0_1440w.jpg" data-size="normal" data-rawwidth="529" data-rawheight="537" class="origin_image zh-lightbox-thumb lazy" width="529" data-original="https://pic1.zhimg.com/v2-aee1af9c3b884c3314f5071db827cfa0_r.jpg" data-actualsrc="https://pic1.zhimg.com/v2-aee1af9c3b884c3314f5071db827cfa0_b.jpg" data-lazy-status="ok" style="display: block; max-width: 100%; margin: 0px auto; cursor: zoom-in; background-color: transparent; animation: 0.5s ease-in 0s 1 normal none running fxRichTextFadeIn;"/><figcaption style="margin-top: 0.66667em; padding: 0px 1em; font-size: 0.9em; line-height: 1.5; text-align: center; color: rgb(153, 153, 153);">BTN RFI vs SB 3bet</figcaption></figure>

例子三，BTN 3bet CO，BTN 同样使用的是一个较宽的 3bet 范围，我们继续使用较宽的范围进行 4bet，这里利用同色 Ace 和 AJo 这种有阻断牌进行 4bet 诈唬(而不是 call 3bet)的比例稍多了一些，我们没有位置，不希望 call 从而去在没有位置，也没有主动权的情况下玩一个 3bet 底池。

<figure data-size="normal" style="margin: 1.4em 0px; color: rgb(26, 26, 26); font-family: -apple-system, BlinkMacSystemFont, &#34;Helvetica Neue&#34;, &#34;PingFang SC&#34;, &#34;Microsoft YaHei&#34;, &#34;Source Han Sans SC&#34;, &#34;Noto Sans CJK SC&#34;, &#34;WenQuanYi Micro Hei&#34;, sans-serif; font-size: medium; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;"><img src="https://pic2.zhimg.com/80/v2-9c309897c41390fdb40f0e459808b881_1440w.jpg" data-size="normal" data-rawwidth="535" data-rawheight="535" class="origin_image zh-lightbox-thumb lazy" width="535" data-original="https://pic2.zhimg.com/v2-9c309897c41390fdb40f0e459808b881_r.jpg" data-actualsrc="https://pic2.zhimg.com/v2-9c309897c41390fdb40f0e459808b881_b.jpg" data-lazy-status="ok" style="display: block; max-width: 100%; margin: 0px auto; cursor: zoom-in; background-color: transparent; animation: 0.5s ease-in 0s 1 normal none running fxRichTextFadeIn;"/><figcaption style="margin-top: 0.66667em; padding: 0px 1em; font-size: 0.9em; line-height: 1.5; text-align: center; color: rgb(153, 153, 153);">CO RFI vs BTN 3bet</figcaption></figure>

总结一下，当我们的 RFI 遭遇到对手的 3bet 时，我们应该使用一个 **极化 **的 4bet 范围，通常来说我们的 4bet 范围应该根据对手的 3bet 范围的宽度进行调整，而不是拥有一种固定的手牌组合，这样会被对手的 3bet 剥削很多。4bet 的种类手牌由两种手牌构成，价值手牌和诈唬手牌，其中价值手牌主要包括一些好的起手牌，例如 AKs，QQ+。诈唬手牌**主要**包括同色 Ace 和中低同色连张，也偶尔会有一些带 blocker 的非同色 broadway。

