title: BBR+BBR魔改+Lotsever(锐速)一键脚本 for Centos/Debian/Ubuntu
date: '2019-09-04 17:12:54'
updated: '2020-07-22 15:50:14'
tags: [技术分享, bbr]
permalink: /articles/2019/09/05/1567613574813.html
---
![](https://img.hacpai.com/bing/20171226.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 教程更新

```
【2018年12月24日】
脚本新增BBRplus修正版，解决原版bbr在高丢包率下易失速以及bbr收敛慢的问题。尝试使其更好，减少排队和丢包。
【2018年3月8日】
脚本新增南琴浪的暴力魔改BBR，使速度更加暴力，实际效果因线路而定。

```

## 脚本安装

**支持系统：**`CentOS 6+`、`Debian 8+`、`Ubuntu 14+`。

**注意：**该脚本在`Vultr`各个系统均测试通过，如果期间有出现任何问题，可向原作者反映帮助改善。  
运行以下命令：

```
wget -N --no-check-certificate "https://raw.githubusercontent.com/chiakge/Linux-NetSpeed/master/tcp.sh" && chmod +x tcp.sh && ./tcp.sh

```

`Ubuntu 18.04`魔改`BBR`暂时有点问题，可使用以下命令安装：

```
wget -N --no-check-certificate "https://raw.githubusercontent.com/chiakge/Linux-NetSpeed/master/tcp.sh"
apt install make gcc -y
sed -i 's#/usr/bin/gcc-4.9#/usr/bin/gcc#g' '/root/tcp.sh'
chmod +x tcp.sh && ./tcp.sh

```

[![请输入图片描述](https://www.moerats.com/usr/picture/qianyingbbr(1).png)](https://www.moerats.com/usr/picture/qianyingbbr(1).png)

使用脚本后会出现如下选项：  
  
根据自己需求操作，重启后再使用`./tcp.sh`命令接着操作。

[![请输入图片描述](https://www.moerats.com/usr/picture/qianyingbbr(2).png)](https://www.moerats.com/usr/picture/qianyingbbr(2).png)

如果在删除内核环节出现这样一张图  
  
注意选择`NO`，然后根据提示重启系统。

最后由于本脚本集成加速太多，兼容性可能不是很好，对于部分系统`BBR`安装不成功的，可以参考博客其它脚本。

* [超级暴力版魔改BBR一键脚本 for Debian](https://www.moerats.com/archives/523/)
* [OpenVZ平台魔改BBR一键脚本之Rinetd方式](https://www.moerats.com/archives/504/)
* [魔改BBR一键安装脚本 for Debian/CentOS](https://www.moerats.com/archives/382/)

对于速度提成来说，锐速效果最好，魔改`BBR`和`BBR`修正版由于`VPS`网络不同测试效果不一，具体效果还是自己先测试一下再选择吧。
