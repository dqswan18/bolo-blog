title: Ssmgr面板不统计流量原因排查
date: '2019-09-09 09:48:02'
updated: '2020-07-22 16:51:14'
tags: [技术分享, ssmgr]
permalink: /articles/2019/09/09/1568015282710.html
---
![](https://img.hacpai.com/bing/20171109.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

  今天升级了自己的三台世界加速服务器，但是发现面板不统计流量，也不显示用户在线情况。但是连接，建账号一切都是正常的。于是开始了我的排查之旅。
![image.png](https://img.hacpai.com/file/2019/09/image-e1c6d11f.png)

1.第一反应是不是数据库损坏，导致无法写入，下载数据库后发现一切正常。排除
2.是不是某个节点因为升级过程中有覆盖，于是重新查看了相应的配置文件，发现正常。排除
3.肯定是主服务器问题，而且又排除了数据库问题，设置也都没有问题，那么我首先想到的就是Redis了。
```
redis-cli    //登陆
```
```
flushall  //清除缓存
```
```
redis-cli -h 127.0.0.1 -p 6379 shutdown  //关闭redis
```
```
redis-server //启动redis
```
清除库缓存并重启后发现一切正常。果然是缓存惹的祸。不过在不确定缓存是否重要的时候，不建议使用盲目的删除，以免重要数据丢失。

![image.png](https://img.hacpai.com/file/2019/09/image-b072a4c8.png)

