title: Ubuntu软件更新运维
date: '2020-02-19 08:41:47'
updated: '2020-07-22 22:47:56'
tags: [Ubuntu, 技术分享]
permalink: /articles/2020/02/19/1582072907536.html
---
![](https://img.hacpai.com/bing/20181231.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

回到家，又身处于墙内，所以赶紧对自己的世界加速服务器进行维护，因为我所有的系统均采用的是Ubuntu 18.04，所以更新起来还算方便，在这里把相关更新命令及出错后的解决办法记录下来，方便自己日后查看。

1.升级安装包相关的命令，刷新可安装的软件列表(但是不做任何实际的安装动作)
```
apt-get update 
```

2.进行安装包的更新(软件版本的升级)
```
apt-get upgrade
```

3.进行系统版本的升级(Ubuntu 版本的升级)
```
apt-get dist-upgrade
```

Ubuntu 官方推荐的系统升级方式，若加参数-d 还可以升级到开发版本，但会不稳定
```
do-release-upgrade
```
错误：但是这里可能在使用

```
apt-get upgrade
```
可能会出现错误如下图
![image.png](https://img.hacpai.com/file/2020/02/image-3bdfcc06.png)
那么这里只需要执行下面的命令，并且接受变更即可
```
sudo apt update
```
最后清除不需要的旧部件
```
sudo apt autoremove
```
